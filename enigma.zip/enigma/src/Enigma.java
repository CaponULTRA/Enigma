public class Enigma {
    private int rotorCount;
    private int [] rotor;
    private String [] plug;
    private int Reverser;
    public Enigma(int rotorCount, int[] rotor, int [] plug, int reverser ){

    }
}
